/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = () => {
  let callbacks;
  let done = false;

  const p = new Promise((resolve, reject) => {
    callbacks = { resolve, reject };
  });

  p.done = () => done;
  p.resolve = val => {
    callbacks.resolve(val);
    done = true;
    return p;
  };
  p.reject = val => {
    callbacks.reject(val);
    done = true;
    return p;
  };

  return p;
};

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__livereload__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__badge__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__reload__ = __webpack_require__(5);
/* global chrome */




const badge = Object(__WEBPACK_IMPORTED_MODULE_1__badge__["a" /* default */])({chrome})
const reload = Object(__WEBPACK_IMPORTED_MODULE_2__reload__["a" /* default */])({chrome})

//////////////////////////////////////////////

const reloadExtensions = async msg => {
  console.log('msg',msg)
  const reloaded = await reload(msg)
  if (reloaded.length)
    badge.tempSet('ok')
  reloaded.forEach(async ext=>
    console.log(`reloaded ${ext.name}`))
}

const messenger = {
  message (msg){
    if (msg && msg.error)
      return onError(msg.error)

    if (msg && msg.command === 'reload')
      reloadExtensions(msg)
  },
}

const onOpen = ()=> {
  console.log('connected to livereload')
  badge.set('connected')
  badge.tempSet('ok', 1200)
  chrome.browserAction.onClicked.removeListener(connect)
  chrome.browserAction.onClicked.addListener(disconnect)
}

const onClose = ()=> {
  console.log('disconnected from livereload')
  if (badge.activeBadge() !== 'no') {
    badge.set('hide')
    badge.tempSet('disconnected', 1200)
  }
  chrome.browserAction.onClicked.removeListener(disconnect)
  chrome.browserAction.onClicked.addListener(connect)
}

const onError = err=> {
  badge.set('hide')
  badge.tempSet('no', 1900)
  console.error(err)
}

const lrSocket = Object(__WEBPACK_IMPORTED_MODULE_0__livereload__["a" /* default */])({
  onOpen,
  onClose,
  WebSocket,
  messenger,
  onError,
})

const connect = ()=> lrSocket.connect()
const disconnect = ()=> lrSocket.disconnect()

chrome.browserAction.onClicked.addListener(()=> {
  badge.set('disconnected')
  lrSocket.connect()
})


//


/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_empty_promise__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_empty_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_empty_promise__);



const handshake = JSON.stringify({
  command: 'hello',
  protocols: [
    'http://livereload.com/protocols/official-7',
    'http://livereload.com/protocols/official-8',
    'http://livereload.com/protocols/2.x-origin-version-negotiation',
    'https://livereload.com/protocols/official-7',
    'https://livereload.com/protocols/official-8',
    'https://livereload.com/protocols/2.x-origin-version-negotiation',
  ],
})

// Instead of throwing. Let's provide some defaults that
// give consumer dev some feedback about missing dependency
// without completely failing.
const unimplemented = {
  onOpen: ()=> console.log('Missing onOpen listener.'),

  onClose: ()=> console.log('Missing onClose listener.'),

  onError: e=> {
    console.log('Error thrown, but no onError to pass it to.')
    console.error(e)
  },

  messenger: {
    message: msg=> console.log(
      'Missing messenger. \nmessage:',
      msg),
  },

  // This dependency is special. Can't even try to do
  // anything without it. So throw instead of warn.
  WebSocket: function (){
    throw 'Missing WebSocket constructor.'
  },

}
/**
 * Factory provider of a LiveReload client implentation
 *
 * @param {Number}    port        port for server
 *
 * @param {String}    host        hostname for server
 *
 * @param {Function}  onOpen      Callback after connection is
 *                                opened.
 *
 * @param {Function}  onClose     Callback after connection is
 *                                closed
 *
 * @param {Function}  onError     Callback after any error.
 *                                This module tries to suppress
 *                                thrown errors, and instead
 *                                passes them to onError.
 *
 * @param {Function} WebSocket   An implentation of WebSocket
 *
 * @param {Object}    messenger   An object with a `message`
 *                                method, which accepts an
 *                                object parameter.
 *
 * @return {Object}               API object with 2 methods:
 *                                `connect` and `disconnect`
 */
function makeLivereloadSocket ({
  // Seems reasonable to use LiveReload's default
  // port on localhost if none provided.
  port = 35729,
  host = 'localhost',
  onOpen = unimplemented.onOpen,
  onClose = unimplemented.onClose,
  onError = unimplemented.onError,
  messenger = unimplemented.messenger,
  WebSocket = unimplemented.WebSocket,
}) {

  let socket // insert active socket here ;)

  // Initiate connection and add listeners
  // Publicly exposed API method.
  //
  function connect() {
    // nothing to do if already connected
    if ( socket && socket.readyState === 1) return

    try{
      socket = new WebSocket(
        `ws://${host}:${port}/livereload`)
    }
    catch(e) { return void onError(e) }

    socket.onmessage = hello
    socket.onerror = onError // consumer provided callback
    socket.onclose = onClose // consumer provided callback
    socket.onopen = async ()=> {
      const fullyOpened = await yesItsReallyOpen()
      if(fullyOpened) socket.send(handshake)
      else socket.close()
    }

    return socket
  }

  // Close the socket
  // Publicly exposed API method
  //
  function disconnect() {
    if (!socket || !socket.close)
      return void onError(
        new Error('Invalid Disconnect: Cannot close a '
          + 'socket that has never been opened.')
      )
    socket.close()
    return socket
  }

  // Turns out a websocket can emit `open` before it's
  // really open 😡. Let's wait until it's open-state is
  // fully resolved.
  //
  function yesItsReallyOpen(){
    const isOpen = __WEBPACK_IMPORTED_MODULE_0_empty_promise___default()()

    const poll = ()=> {
      if(socket.readyState === 1)
        isOpen.resolve(true)

      else setTimeout(poll, 100)
    }

    // Race against a timeout. 8 seconds is long time to
    // wait for this. But hey, why not?
    setTimeout(() => {isOpen.reject(
      new Error('Timeout: WebSocket half-open too long.'))
    }, 8000),

    poll()
    return isOpen
      .catch(e => { onError(e); return false })
  }

  // Try to parse JSON and pass any error to consumer
  //
  function parseMsg(evt) {
    let msg
    try { msg = JSON.parse(evt.data) }
    catch (e) { onError(
      new Error('Invalid JSON from LiveReload server.')
    )}
    return msg
  }

  // Must receive hello from server before other messages.
  //
  function hello(evt) {
    const msg = parseMsg(evt)
    const helloError =
      new Error('Invalid "hello" from server')

    if (!msg || msg.command !== 'hello') {
      onError(helloError)
      return void socket.close()
    }

    listen()
  }

  // Switch to listening for arbitrary incoming messages.
  //
  function listen() {
    socket.onmessage = evt=> {
      const msg = parseMsg(evt)
      if (!msg)
        return void socket.close()

      if (msg.command === 'reload')
        messenger.message(msg)
    }
    // Finally reached state consumer would view as open
    onOpen() // consumer provided callback
  }

  return { connect, disconnect }
}

/* harmony default export */ __webpack_exports__["a"] = (makeLivereloadSocket);


/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

function makeBadge({chrome}) {
  let state = {
    badge: '',
    pending: undefined,
  }

  const badges = {
    hide: { text: '' },
    ok: {
      text: ' OK ',
      color: '#44992c',
    },
    no: {
      text: ' NO ',
      color: '#f33',
    },
    connected: {
      text: ' -(c- ',
      color: [42,181,130,200],
    },
    disconnected: {
      text: '-(  c-',
      color: [179,179,29,200],
    },
  }

  const browserAction = chrome.browserAction

  function set(badge) {
    if (state.pending) {
      clearTimeout(state.pending)
      state.pending = undefined
    }

    if (!badges[badge]) throw Error(
      `Badge Error: Tried to set non-existant badge ${badge}`)

    const text = badges[badge].text
    browserAction.setBadgeText({ text })

    const color = badges[badge].color
    if (color) browserAction
      .setBadgeBackgroundColor({ color })

    state.badge = badge
  }

  function tempSet(badge, delay) {
    const current = state.badge
    if (current === badge) return

    state.pending = delaySet(current, delay)
    set(badge)
  }

  function delaySet(badge, delay) {
    setTimeout(
      ()=> set(badge),
      delay || 1200,
    )
  }

  function activeBadge() {
    return state.badge
  }

  return { set, tempSet, activeBadge }
}

/* harmony default export */ __webpack_exports__["a"] = (makeBadge);


/***/ }),
/* 5 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_empty_promise__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_empty_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_empty_promise__);


/* harmony default export */ __webpack_exports__["a"] = (makeReload);

function makeReload ({chrome}){
  /**
   * Reloads active developer mode extensions and apps
   * @async
   * @param  {Object}  msg            A reload message from
   *                                  livereload
   * @return {Array.<ExtensionInfo>}  Chrome ExtensionInfo
   *                                  objects for extensions
   *                                  & apps that reloaded
   */
  return async msg=> {
    const ChrMgt = chrome.management

    async function reload (ext) {
      const reloaded = __WEBPACK_IMPORTED_MODULE_0_empty_promise___default()()

      // enabled -> disabled -> enabled == reload
      ChrMgt.setEnabled(ext.id, false, ()=>
        ChrMgt.setEnabled(ext.id, true, reloaded.resolve))
      await reloaded

      // Forward msg in case extension wants to know
      const forwardMsg = ()=>
        chrome.runtime.sendMessage(ext.id, msg)

      // apps still need to launch to finish reload
      if (ext.type.match(/app/))
        ChrMgt.launchApp(ext.id, forwardMsg)

      // extensions should be up already
      else forwardMsg()

      return ext
    }

    const extensions = __WEBPACK_IMPORTED_MODULE_0_empty_promise___default()()
    ChrMgt.getAll(extensions.resolve)

    const reloaded = (await extensions)
      .filter(extension=>
        // installed as unpacked folder
        extension.installType === 'development'
        // if app not specified, only reload enabled
        && extension.enabled === true
        // Clerc shouldn't reload itself
        && extension.id !== chrome.runtime.id
      )
      // and... Go!! :)
      .map(reload)
    return Promise.all(reloaded)
  }
}


/***/ })
/******/ ]);